29.10. 266€ JetBrains x

7.1. 800€ Laptop (keine Rechnung)

x.11. \~850€ Desktop PC x

25.11. 520€ Grafikkarte + Lüfter x

23.11. DisplayPort-Kabel x

Ugreen KVM Switch x

31.07. **40,97** Ugreen Netzteil (keine Rechnung)

Ugreen Docking Station x

Bildschirm(e)?

Tastatur?

End of year 70€ Hard drive

server costs!

Anthropic credit!