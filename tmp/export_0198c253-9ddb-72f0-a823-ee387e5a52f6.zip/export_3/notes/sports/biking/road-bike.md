# Cube Agree Compact (2009)

| Farbe                     | Racing Red                                                                         |
| ------------------------- | ---------------------------------------------------------------------------------- |
| Rahmenhöhe                | 56                                                                                 |
| Schalt- & Bremsgruppe     | Shimano Ultegra SL 6600                                                            |
| Gabel                     | Dedacciai Black Blade Carbon                                                       |
| Rahmen                    | HPA 7005 Triple Butted                                                             |
| Lenker                    | Syntace Racelit 2014                                                               |
| Umwerfer hinten           | Shimano Ultegra SL RD-6600SSG                                                      |
| Umwerfer vorne            | Shimano Ultegra SL FD-6600BLG (2-speed)                                            |
| Schalt- / Bremshebel      | Shimano Ultegra SL ST-6600G (10-speed)                                             |
| Bremsen                   | Shimano Ultegra SL BR-6600G                                                        |
| Kettenblatt- & Kurbel-Set | Shimano Ultegra SL FC-6650 Hollowtech II 50x34T<br>großes Blatt: Shimano SG-X 50-F | 
| Kasette                   | Shimano Ultegra CS-6600 12-27T                                                     |
| Kette                     | Shimano Ultegra CN-6600 106 links                                                  |
| Laufräder                 | Easton Vista SL                                                                    |
| Reifen                    | Continental GP-4000 S II                                                           |
| Sattel                    | Fi’zi:k Aliante Delta                                                              |
| Sattelstütze              | RFR Prolight 31.6mm Setback                                                        |
| Seat Clamp                | Scape Close 34.9mm                                                                 |
| Rahmengewicht             | 1360g                                                                              |
| Gesamt-Gewicht            | 8.1kg                                                                              |

Catalogue: [https://www.fahrrad-goyn.de/cube/cube-bike-katalog-2009/](https://www.fahrrad-goyn.de/cube/cube-bike-katalog-2009/)