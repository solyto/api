> Mit zunehmendem Alter (in der Regel nach dem 40. Lebensjahr) werden die Episoden seltener, aber einige Patienten entwickeln in unterschiedlichem Ausmaß eine Myopathie mit bleibender Muskelschwäche.

https://www.orpha.net/de/disease/detail/682

<br>

> Treatment for HYPP is both proactive and reactive, with avoidance of triggers being the mainstay of therapy. It is important to diagnose this condition quickly and accurately as long-term complications, including weakness and fatigue, can lead to a decrease in the quality of life.

https://www.ncbi.nlm.nih.gov/books/NBK564319/

<br>

> Affected individuals may also present with paramyotonia (muscle stiffness or inability to relax muscles)

https://www.ncbi.nlm.nih.gov/books/NBK564319/

<br>

> The attacks initially are uncommon; however, they increase in intensity and frequency until the fifth decade of life, at which point there is a steep decline. Common triggers are potassium-rich foods, a cold environment, and rest after physical activity.

https://www.ncbi.nlm.nih.gov/books/NBK564319/

<br>

> Individuals over 40 years of age commonly report permanent muscle weakness, with a third of individuals developing chronic progressive myopathy.[[5]](https://www.ncbi.nlm.nih.gov/books/NBK564319/#)

https://www.ncbi.nlm.nih.gov/books/NBK564319/

<br>

> The treatment approach should include both the management of acute attacks and the prevention of attacks. Treatments include behavioral interventions directed at avoiding triggers and modifying potassium levels through diet, diuretics, and carbonic anhydrase inhibitors. Attacks may be treated at the onset of weakness with mild physical activity, oral intake of carbohydrate-rich foods, salbutamol inhalation, or intravenous calcium gluconate.[[8]](https://www.ncbi.nlm.nih.gov/books/NBK564319/#) [Level 3]

https://www.ncbi.nlm.nih.gov/books/NBK564319/#

<br>

> Individuals should avoid potassium-rich medications and foods, fasting, strenuous work, and exposure to cold to prevent attacks.

https://www.ncbi.nlm.nih.gov/books/NBK564319/#

<br>

> Individuals who develop permanent muscle weakness may require lifelong thiazide diuretics and interval MRI of the proximal leg muscle every 1 to 3 years.

https://www.ncbi.nlm.nih.gov/books/NBK564319/#

<br>

> Prophylactic treatment necessitates serum potassium levels twice yearly to avoid diuretic complications and annual evaluation of thyroid function. It is imperative to avoid factors that may precipitate an episode. These include ingesting potassium-rich food or medications, prolonged fasting, intense physical activity, a cold environment, and depolarizing anesthetic agents that may be used during general anesthesia.[[5]](https://www.ncbi.nlm.nih.gov/books/NBK564319/#) [Level 5]

https://www.ncbi.nlm.nih.gov/books/NBK564319/#

<br>

> Common hereditary disorders that cause hyperkalemia include adrenal insufficiency, recessive infantile hypoaldosteronism, pseudohypoaldosteronism type 1, and pseudohypoaldosteronism type 2.

https://www.ncbi.nlm.nih.gov/books/NBK564319/#

<br>

> The possible long-term sequelae confer a poor prognosis for those affected with this condition.

https://www.ncbi.nlm.nih.gov/books/NBK564319/#

<br>

> Permanent weakness occurred in 68%, muscle pain in 82% and muscle fatigue in 89%. Eighty-three percent of patients reported themselves as moderately to very active between ages 18-35. At the time of the survey only 14% reported themselves as moderately to very active. Contrary to the literature, only 21% of patients reported decreased frequency of episodic weakness with increased age. Sixty-seven percent had incurred injuries due to falls. Mobility aids were required by 49%.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3476862/

> -> Seventy percent (70%) of participants were diagnosed as HypoPP, 9% as HyperPP, 6% as paramyotonia congenita (PC), 9% as Andersen syndrome (AS), and 6% were clinically diagnosed as periodic paralysis without specification of a subtype (excerpt of data in [Table 1](https://pmc.ncbi.nlm.nih.gov/articles/PMC3476862/#T1)).

<br>

> 92% had reduced strength and stamina, 89% reported difficulty performing activities of daily living, 89% felt limited in the type of work and activities they are able to do, 75% experienced difficulties with mild exercise, 55% report lack of endurance, 42% could climb only a single flight of stairs, 25% were unable to walk more than a few steps unaided.

https://pmc.ncbi.nlm.nih.gov/articles/PMC3476862/#R03

<br>

> for HyperPP there are carbamazepine, fludrocortisone and the angiotensin I receptor antagonist, irbesartan;

https://pmc.ncbi.nlm.nih.gov/articles/PMC3476862/#R03

<br>

> What triggers an episode varies from patient to patient and may be caused by a variety of factors such as stress, eating certain foods, consuming alcohol, resting after exercise, sleep, becoming chilled or overheated.

https://hkpp.org/

<br>

> Hyperkalemic periodic paralysis (HyperPP or HyperKPP) is a type of periodic paralysis in which attacks are often associated with high potassium levels in the blood or that are triggered by elevation of blood potassium.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> Individuals with HyperPP have varying degrees of transient muscle stiffness (myotonia) and episodes of weakness. If the predominant feature is muscle stiffness that is aggravated by cold temperatures and paradoxically worsens over the first few repeated attempts of movement, then this disorder is usually called paramyotonia congenita (PMC).

> Many patients with HyperPP will eventually develop a slowly progressive permanent muscle weakness, which is called myopathy. This might happen as the patient reaches their 50s or 60s. Some patients with myopathy use a wheelchair or scooter to help them get around outside the house to ease the strain on their weakened muscles. However, they are still able to have fulfilling lives and do many kinds of activities.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> The more stress a patient feels in their day-to-day life, the more likely it is that they will have an attack.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> Because there are many triggers and different people will have different triggers, it is recommended that patients keep a trigger diary. After you have an attack, you should write down what happened, how you felt, what you were doing before the attack, and how you were able to recover from it. After doing this for a while, you’ll be able to look back on your previous diary entries and notice certain patterns.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> Usually, the attacks start out not being very frequent, but as the patient reaches their 30s, there are more attacks. Then, in their 50s, the patient might have fewer attacks, but their muscles have been permanently weakened (myopathy).

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> Avoid exercise that is overly intense, because resting after an intense workout can be a trigger.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> Involve an Endocrinologist to rule out adrenal causes of hypokalemia.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>

> Emergency Management
> Hyperkalemic Periodic Paralysis Management: Acute Attack
> Control of hyperkalemia:
> Consider just giving a candy bar and waiting. Depends on the degree of paralysis.
> Insulin (with glucose to prevent hypoglycemia)
> Albuterol nebulizer
> Sodium Bicarbonate – 44-50 mEq over 5 min.
> Hypertonic saline
> Hydrochlorothiazide
> Calcium administration intravenously (1 amp of 10% calcium gluconate) – under cardiac monitoring and only if EKG shows signs of severe hyperkalemia
> Position patient comfortably
> EKG for rhythm, especially QT interval.
> Monitor serum potassium q30min to 120min, depending on the condition of the patient and the medications being administered.
> Do not leave patients unattended! Conditions can change for better or worse rapidly. Risk of aspiration.

https://periodicparalysis.org/what-is-periodic-paralysis-2/hyperkalemic-periodic-paralysis/

<br>
Triggers include cold environment; rest after exercise, stress, or fatigue; alcohol; hunger; changes in activity level; potassium in food; specific foods or beverages; changes in humidity; extra sleep; pregnancy; illness of any type; menstruation; medication; and potassium supplements [Charles et al 2013]. The major attack trigger is eating potassium-rich foods.
> Fortunately, there is hope. Periodic paralysis can be managed. No matter which of the periodic paralysis types you have, there are treatments out there for you.

https://periodicparalysis.org/medical-treatments-for-periodic-paralysis/

<br>

> It’s important to get hyperkalemic periodic paralysis treatment because even though the muscle weakness attacks are usually temporary, it’s possible that they can eventually cause permanent muscle weakness. One thing you can do is to try to avoid things that trigger the episodes. For example, you may need to cut down on your potassium intake. Managing your stress levels is something else you can do to reduce the likelihood of an episode since stress is a trigger. Writing in a journal about things that make you feel stressed is a good first step to take in managing stress.

https://periodicparalysis.org/medical-treatments-for-periodic-paralysis/

<br>

> Muscle groups for respiration, swallowing, speech, and extraocular movement are largely spared.

https://pmc.ncbi.nlm.nih.gov/articles/PMC11556526/

<br>

> Sustained vigorous exercise is commonly reported to be a trigger, with preserved strength of active muscles and weakness occurring within minutes of stopping to rest. On the other hand, an impending attack can often be prevented or attenuated by mild exercise. Other frequently reported triggers include cold environment, stress, alcohol consumption, and dietary patterns (carbohydrate rich foods for hypokalemic periodic paralysis, HypoPP, versus fasting for hyperkalemic periodic paralysis, HyperPP).

https://pmc.ncbi.nlm.nih.gov/articles/PMC11556526/

<br>

> For many patients the frequency of attacks diminishes with age, and is replaced by a chronic state of mild weakness that later progresses to myopathy with permanent muscle weakness, especially of proximal muscles, and may cause loss of ambulation

<br>

> A change in life-style to minimize triggering events is the first-line approach in symptom management for all types of periodic paralysis. Adjustment of physical activity level is often most effective; either resuming a modest level of exercise to curtail an impending attack or warming down after vigorous exercise to prevent the initiation of an episode. Reducing stress levels (emotional and physical) and similarly avoiding drug preparations that contain adrenergic agents (e.g. epinephrine in local anesthetics) is especially helpful in HypoPP. Dietary adjustments are also effective: avoiding carbohydrates, staying well-hydrated and avoiding high-Na+ foods, or ingesting high-K+ containing foods for HypoPP; avoid fasting and use a carbohydrate snack to abort an attack of HyperPP.

https://pmc.ncbi.nlm.nih.gov/articles/PMC11556526/

<br>

> Effective intervention to minimize or prevent late-onset permanent muscle weakness has not been established. While a causal relationship between the severity and frequency of acute episodes of weakness and the risk of developing has not been established, the general recommendation is to optimize a life-style that minimizes these attacks and maintain a healthy level of physical activity.

<br>

> Most patients with HyperPP also have myotonia, often becoming symptomatic with activity-dependent muscle stiffness that precedes an attack of weakness or asymptomatic but detectable on clinical exam (e.g. percussion myotonia) or by needle EMG. With advancing age, most patients with HyperPP have a slowly progressive proximal myopathy with permanent weakness that may impair ambulation.

<br>

> **Triggers** include cold environment; rest after exercise, stress, or fatigue; alcohol; hunger; changes in activity level; potassium in food; specific foods or beverages; changes in humidity; extra sleep; pregnancy; illness of any type; menstruation; medication; and potassium supplements [[Charles et al 2013](https://www.ncbi.nlm.nih.gov/books/NBK1496/#)]. The major attack trigger is eating potassium-rich foods.

<br>

> Individuals most commonly describe their attacks as stiffness followed by weakness, although many have described their attacks as some other permutation of weakness and/or stiffness. The arms and hands are just as frequently affected as the thighs and calves [[Charles et al 2013](https://www.ncbi.nlm.nih.gov/books/NBK1496/#)].

https://www.ncbi.nlm.nih.gov/books/NBK1496/

<br>

> Frequency of attacks can vary greatly among individuals. Some have attacks every day, others several times a month; others have them every few months or less often.

https://www.ncbi.nlm.nih.gov/books/NBK1496/

<br>

> **Muscle issues.** Individuals with hyperPP frequently (i.e., >50% of the time) have myotonia, especially around the time of an episode of weakness. Mild myotonia (muscle stiffness) that does not impede voluntary movements is often present between attacks. Myotonia is most readily observed in the facial, lingual, thenar, and finger extensor muscles; eyelid myotonia (lid lag myotonia) has been rarely reported. Paramyotonia (muscle stiffness aggravated by cold and exercise) is present in about 45% of affected individuals. Of individuals with myotonia, 37% have experienced progressive myopathy,

https://www.ncbi.nlm.nih.gov/books/NBK1496/

<br>

### Prevention of Primary Manifestations

**Diet/environment.** Preventive measures for individuals with hyperPP consist of frequent meals rich in carbohydrates and **avoidance of the following**:

- Potassium-rich medications and foods (e.g., fruits, fruit juices)
    
- Fasting
    
- Strenuous work
    
- Exposure to cold
    

**Early start to the day.** As attacks occur more frequently on holidays and weekends when people rest in bed longer than usual, individuals are advised to rise early and have a full breakfast.

**Lifestyle.** Individuals should prioritize avoidance or minimization of triggers whenever possible by keeping stress levels low and avoiding exercise that is overly intense (as rest after such exercise is a trigger).

![[Pasted image 20250228193837.png]]