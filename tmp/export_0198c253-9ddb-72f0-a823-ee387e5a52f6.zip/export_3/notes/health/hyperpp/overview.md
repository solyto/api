# Hyperkaliämische periodische Paralyse

## 1. Definition

Die **hyperkaliämische periodische Paralyse**, kurz **hyperPP**, ist eine [Ionenkanalerkrankung](https://flexikon.doccheck.com/de/Kanalopathie), die durch das episodische Auftreten von [Muskellähmungen](https://flexikon.doccheck.com/de/Muskell%C3%A4hmung) gekennzeichnet ist, die von einer [Hyperkaliämie](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mie) begleitet werden. Sie zählt zu den [dyskaliämischen periodischen Paralysen](https://flexikon.doccheck.com/de/Dyskali%C3%A4mische_periodische_Paralyse).

## 2. Epidemiologie

Es handelt sich um eine [seltene Erkrankung](https://flexikon.doccheck.com/de/Seltene_Krankheit). Die [Prävalenz](https://flexikon.doccheck.com/de/Pr%C3%A4valenz) wird auf 0,6 bis 1,7 Fälle pro Million Einwohner beziffert.[[1]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:0-1) Frauen und Männer sind gleichermaßen betroffen. Die Erstmanifestation ereignet sich meist vor dem 5. Lebensjahr, teilweise aber auch erst in der zweiten Lebensdekade.[[1]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:0-1)[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2)[[3]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:2-3)

## 3. Genetik

Zugrunde liegen [autosomal-dominant](https://flexikon.doccheck.com/de/Autosomal-dominanter_Erbgang) vererbbare [Gain-of-Function-Mutationen](https://flexikon.doccheck.com/de/Gain-of-Function-Mutation) im [SCN4A](https://flexikon.doccheck.com/index.php?title=SCN4A&action=edit&redlink=1 "SCN4A (Artikel jetzt erstellen...)")-Gen auf [Chromosom 17q](https://flexikon.doccheck.com/de/Chromosom_17).[[1]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:0-1) Dabei handelt es sich um [Missense-Mutationen](https://flexikon.doccheck.com/de/Missense-Mutation), wobei etwa ⅔ auf die Mutationen p.[Thr](https://flexikon.doccheck.com/de/Threonin)704[Met](https://flexikon.doccheck.com/de/Methionin) und p.[Met](https://flexikon.doccheck.com/de/Methionin)1592[Val](https://flexikon.doccheck.com/de/Valin) entfallen.[[4]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-4)

Das betroffene Gen [kodiert](https://flexikon.doccheck.com/de/Kodieren) für die α-Untereinheit des [spannungsabhängigen Natriumkanals](https://flexikon.doccheck.com/de/Spannungsabh%C3%A4ngiger_Natrium-Kanal) [Nav1.4](https://flexikon.doccheck.com/index.php?title=Nav1.4&action=edit&redlink=1 "Nav1.4 (Artikel jetzt erstellen...)"), der das [Aktionspotential](https://flexikon.doccheck.com/de/Aktionspotential) von Skelettmuskelzellen einleitet.[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2)

Die [Penetranz](https://flexikon.doccheck.com/de/Penetranz) der Mutationen liegt über 90 %.[[1]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:0-1)

## 4. Pathogenese

Die Mutationen des Nav1.4-Kanals führen zu einer unvollständigen schnellen Inaktivierung nach einer [Depolarisation](https://flexikon.doccheck.com/de/Depolarisation). Dadurch kommt es nach einer Muskelstimulation zur [Myotonie](https://flexikon.doccheck.com/de/Myotonie).[[1]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:0-1)

Bei repetetiver Muskelaktivierung tritt eine dauerhafte Positivierung des [Sarkolemm](https://flexikon.doccheck.com/de/Sarkolemm) auf ca. -45 mV auf, insbesondere bei vermindertem Kaliumausstrom durch hohes extrazelluläres Kalium (z.B. nach kaliumreicher Kost oder bei starker Muskelarbeit). Diese Dauerdepolarisation führt zur anhaltenden Inaktivierung von funktionstüchtigen Natriumkanälen (des gesunden [Allels](https://flexikon.doccheck.com/de/Allel)),[[1]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:0-1) es resultiert ein [Depolarisationsblock](https://flexikon.doccheck.com/index.php?title=Depolarisationsblock&action=edit&redlink=1 "Depolarisationsblock (Artikel jetzt erstellen...)") (vgl. [Succinylcholin](https://flexikon.doccheck.com/de/Succinylcholin)).

## 5. Klinik

Kennzeichen der hyperPP sind episodenweise Lähmungsattacken. Sie betreffen vornehmlich die [Hüft](https://flexikon.doccheck.com/de/H%C3%BCftmuskulatur)- und [Schultermuskulatur](https://flexikon.doccheck.com/de/Schultermuskeln), [Gesichts](https://flexikon.doccheck.com/de/Mimische_Muskulatur)- und [Atemmuskulatur](https://flexikon.doccheck.com/de/Atemmuskulatur) bleiben typischerweise ausgespart.[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5) Teilweise finden sich begleitende [Parästhesien](https://flexikon.doccheck.com/de/Par%C3%A4sthesie), davon abgesehen sind [Sensibilitätsstörungen](https://flexikon.doccheck.com/de/Sensibilit%C3%A4tsst%C3%B6rung) jedoch untypisch.[[3]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:2-3)

Auslöser der Episoden sind:[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2)[[3]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:2-3)[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5)

- Ruhen nach körperlicher Aktivität
- Kaliumreiche Kost
- [Kälteexposition](https://flexikon.doccheck.com/de/K%C3%A4lteexposition)
- [Fasten](https://flexikon.doccheck.com/de/Fasten)
- [Stress](https://flexikon.doccheck.com/de/Stress)
- [Infektionen](https://flexikon.doccheck.com/de/Infektion)
- [Glukokortikoide](https://flexikon.doccheck.com/de/Glukokortikoid)
- [Narkosen](https://flexikon.doccheck.com/de/Narkose)
- [Schwangerschaften](https://flexikon.doccheck.com/de/Schwangerschaft)

Die Dauer der Episoden beträgt typischerweise 15 Minuten bis eine Stunde.[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2) Oft kann ihre Symptomatik durch Fortsetzung einer vorherigen körperlichen Aktivität abgemildert werden.[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5)

Anfänglich kommt es nur selten zu leichten paretischen Episoden. Deren Anzahl und Schwere nimmt jedoch bis zur fünften Lebensdekade zu, danach wieder deutlich ab.[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2) Einige Patienten entwickeln jedoch im Verlauf eine progressive [Myopathie](https://flexikon.doccheck.com/de/Myopathie) mit dauerhafter Muskelschwäche.[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2)[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5)

Etwa jeder achte Patient weist außerdem klinisch relevante Myotonien auf. Vornehmlich betroffen ist die mimische Muskulatur, z.B. als Lidschluss-Myotonie. Diese sind permanent auslösbar und milde ausgeprägt.[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5)

## 6. Diagnostik

Bei der körperlichen Untersuchung kann eventuell eine Myotonie beobachtet werden.

Ansonsten sind die Patienten vor allem während einer Episode auffällig. Hier findet sich neben proximal betonten Paresen ein erhöhtes [Serumkalium](https://flexikon.doccheck.com/de/Serumkalium). Anfallsprovokationen zu diagnostischen Zwecken werden jedoch nicht mehr empfohlen.[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2)

Im [EMG](https://flexikon.doccheck.com/de/Elektromyographie) können myotone Entladungen (50 % d.F.) sowie im Verlauf eventuell myopathische Veränderungen zu sehen sein.[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5)

Gesichert wird die Diagnose durch [molekulargenetischen Nachweis](https://flexikon.doccheck.com/de/Molekulargenetische_Untersuchung) der auslösenden Mutation, z.B. per [Sequenzierung](https://flexikon.doccheck.com/de/Next_Generation_Sequencing) des SCN4A-Gens.[[6]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-6)

## 7. Differenzialdiagnostik

Differenzialdiagnostisch sind unter anderem zu bedenken:

- andere periodische Paralysen, z.B.:
    - [hypokaliämische periodische Paralyse](https://flexikon.doccheck.com/de/Hypokali%C3%A4mische_periodische_Paralyse)
    - [Andersen-Tawil-Syndrom](https://flexikon.doccheck.com/de/Andersen-Tawil-Syndrom)
- [Muskelschwäche](https://flexikon.doccheck.com/de/Myasthenie) durch anderweitig ausgelöste [Hyperkaliämie](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mie)
- [psychogene Paresen](https://flexikon.doccheck.com/de/Dissoziative_Konversionsst%C3%B6rung)

## 8. Therapie

Eine kausale Therapie ist derzeit (2024) nicht verfügbar.

In erster Linie gilt es, auslösende Faktoren zu vermeiden und den Kaliumspiegel niedrig zu halten. Empfohlen wird die häufige Aufnahme kohlenhydratreicher, kaliumarmer Mahlzeiten sowie kontinuierliche leichte Muskelarbeit. Intensive Muskeltätigkeit, kaliumreiche Nahrung bzw. Pharmaka, Kälteexposition und Fasten sollen vermieden werden.[[2]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:1-2)[[3]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:2-3)

Auch kaliumsenkende Pharmaka, z.B. [Thiazide](https://flexikon.doccheck.com/de/Thiaziddiuretikum) oder [Azetazolamid](https://flexikon.doccheck.com/de/Acetazolamid), können verabreicht werden. Zu Beginn eines Anfalls verabreichtes [Salbutamol](https://flexikon.doccheck.com/de/Salbutamol), was ebenfalls das Serumkalium senkt, kann diesen teilweise unterdrücken.[[5]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:3-5) Zur Unterbrechung schwerer Anfälle können [Insulin](https://flexikon.doccheck.com/de/Insulin)-Glucose-Infusionen oder [Calciumgluconat](https://flexikon.doccheck.com/de/Calciumgluconat) infundiert werden.[[3]](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_note-:2-3)

## 9. Einzelnachweise

1. ↑ [1,0](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:0_1-0) [1,1](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:0_1-1) [1,2](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:0_1-2) [1,3](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:0_1-3) [1,4](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:0_1-4) [1,5](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:0_1-5) Weber, [Hyperkalemic Periodic Paralysis](https://www.ncbi.nlm.nih.gov/books/NBK1496/). In: Adam et al. (Hrsg.), GeneReviews. University of Washington, 2021.
2. ↑ [2,0](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-0) [2,1](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-1) [2,2](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-2) [2,3](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-3) [2,4](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-4) [2,5](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-5) [2,6](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-6) [2,7](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:1_2-7) Sekhon, Vaqar, Gupta, [Hyperkalemic Periodic Paralysis](https://www.ncbi.nlm.nih.gov/books/NBK564319/). StatPearls, 2021.
3. ↑ [3,0](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:2_3-0) [3,1](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:2_3-1) [3,2](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:2_3-2) [3,3](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:2_3-3) [3,4](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:2_3-4) Gehlen et al. (Hrsg.), [Neurologie](https://eref.thieme.de/N5Y4G). 12., vollständig überarbeitete Auflage. Thieme Verlag Stuttgart, 2010.
4. [↑](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-4) Ammar et al., [Understanding the physiology of the asymptomatic diaphragm of the M1592V hyperkalemic periodic paralysis mouse](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4664826/). Journal of General Physiology, 2015.
5. ↑ [5,0](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-0) [5,1](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-1) [5,2](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-2) [5,3](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-3) [5,4](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-4) [5,5](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-5) [5,6](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-:3_5-6) Vicart, [Paralyse, hyperkaliämische periodische](https://www.orpha.net/de/disease/detail/682). Orphanet, 2010.
6. [↑](https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse#cite_ref-6) [Eintrag zu periodischen Paralysen](https://www.mgz-muenchen.de/erkrankungen/diagnose/periodische-paralyse.html), Internetauftritt des Medizinisch Genetischen Zentrums München. Aufgerufen am 04.09.2024.

**Stichworte:** [Ionenkanalerkrankung](https://flexikon.doccheck.com/de/Kategorie:Ionenkanalerkrankung), [Kaliumhaushalt](https://flexikon.doccheck.com/de/Kategorie:Kaliumhaushalt), [Lähmung](https://flexikon.doccheck.com/de/Kategorie:L%C3%A4hmung), [Neuromuskuläre Erkrankung](https://flexikon.doccheck.com/de/Kategorie:Neuromuskul%C3%A4re_Erkrankung), [Parese](https://flexikon.doccheck.com/de/Kategorie:Parese)

**Fachgebiete:** [Neurologie](https://flexikon.doccheck.com/de/Kategorie:Neurologie)