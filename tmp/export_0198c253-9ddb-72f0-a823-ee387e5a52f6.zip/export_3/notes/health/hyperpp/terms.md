Hyperkaliämische periodische Paralyse
Hyperkaliämische periodische Paralyse mit Myotonie
Myotonie / myotonia
proximal myopathy with permanent weakness
Andersen-Tawil-Syndrom
Permanent muscle weakness (PMW)

**Normo- and hyperkalemic paralysis (normo/hyperPP)**