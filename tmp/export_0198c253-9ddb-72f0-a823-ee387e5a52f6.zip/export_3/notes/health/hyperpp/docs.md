https://www.uniklinikum-dresden.de/de/das-klinikum/kliniken-polikliniken-institute/neu
https://www.mdc-berlin.de/de/ecrc/hochschul-ambulanzen/muskelkrankheiten
https://www.neuropsychiatricum-bremen.de/index.php/leistungen/2012-09-10-15-08-15