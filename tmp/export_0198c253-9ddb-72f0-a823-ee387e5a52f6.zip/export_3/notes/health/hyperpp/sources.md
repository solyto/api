https://flexikon.doccheck.com/de/Hyperkali%C3%A4mische_periodische_Paralyse
https://www.orpha.net/de/disease/detail/682
https://www.ncbi.nlm.nih.gov/books/NBK564319/

The impact of permanent muscle weakness on quality of life in periodic paralysis: a survey of 66 patients
https://pmc.ncbi.nlm.nih.gov/articles/PMC3476862/

Periodic Paralysis International (PPI)
https://hkpp.org/

Periodic Paralysis Association
https://periodicparalysis.org/

Images
https://neuromuscular.wustl.edu/pathol/hopp.htm

Study
https://link.springer.com/content/pdf/10.1007/s00415-013-7025-9.pdf

Medikament
https://www.keveyis.com/

Dr. Cannon Studien
https://pubmed.ncbi.nlm.nih.gov/?cmd=PureSearch&term=Cannon+SC[Author]

Neuste Studie von Dr. Cannon
https://pmc.ncbi.nlm.nih.gov/articles/PMC11556526/#S11

Relevante Studie von 2015
https://pmc.ncbi.nlm.nih.gov/articles/PMC4754081/

Videos
https://periodicparalysis.org/2023-ppa-conference/

Deutsche Studie
https://www.ncbi.nlm.nih.gov/books/NBK1496/#

Deutsche Webseite
https://menschundmyotonie.de/mmwp/