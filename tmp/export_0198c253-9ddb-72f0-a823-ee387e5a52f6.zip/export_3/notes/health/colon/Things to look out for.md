Gesund ernähren, viel Obst und Gemüse

keine angebrannten/schwarzen Dinge essen





Wenn folgende Symptome auftreten, beim Arzt melden:

* Starkes Schwitzen in der Nacht (z.B. man muss 2-3 mal in der Nacht das T-Shirt wechseln)
* Starker Durchfall (1-2 Wochen lang)
* Anhaltende Verstopfungen