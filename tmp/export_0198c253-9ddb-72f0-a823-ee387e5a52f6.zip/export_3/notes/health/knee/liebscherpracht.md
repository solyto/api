Morgens:
- Selbst umarmen
- Dehnungsübungen

Abends:
- Selbst umarmen
- abwechselnd drücked/Faszien-Rolle

Laptop & Kabel aus dem Bett raus
Morgens Smartphone erst nach Übungen anschauen
Bewegung!

Übungen:
- 30 Sekunden passiv dehnen
- 10 Sekunden mit maximaler Kraft gegenspannen
- 20 Sekunden passiv dehnen
- 10 Sekunden mit maximaler Kraft gegenspannen
- 20 Sekunden passiv dehnen
- 10 Sekunden mit maximaler Kraft gegenspannen
- 20 Sekunden passiv dehnen
- 10 Sekunden aktiv dehnen