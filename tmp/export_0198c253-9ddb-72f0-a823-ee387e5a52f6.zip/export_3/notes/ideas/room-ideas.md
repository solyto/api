**What do I want?**

* cozy
* lots of place for music and books
* a comfortable way to relax in my room without having to go to bed
* ideal: room for clothes and clothes in use





**Ideas**

* more shelves for books -> not great to reach
* a CD cabinet
* a nice platform for the Monstera
* a clothes cabinet -> more place for tools in the workshop and clean separation





**New furniture**

* Chair and stool
* Sidetable / couch table, big enough for tea stuff
* Closet for clothes

  * Places: where the desik is, corner under book shelves, at the window
* Maybe a rug





**What do I want to keep**

* Bed where it is
* Desk, probably where it is
* Sideboard for vinyl
* Standing lamp from grandpa





**What can go**

* Old standing lamp
* Keyboard -> attic





**Concrete options**

* Monstera between desk and bed (would be a nice visual upgrade to hide a little of the ugliness of a plain desk) -> character upgrade
* Closet for clothes between workshop door and window (around max. 120cm wide, can be very high) -> decorated by Efeutute
* Small cabinet/sideboard beneath window for more books
* Replace boxes next to sideboard to look more organic and as a place for CDs that is more practical
* Reading chair, stool and couch table in front of the window, reaching into the middle of the room
* Rug in front of reading chair
* -> **Result**: very cozy, much storage, everything in one room, enough place for books, music, etc. Guitars could stay where they are; good view from bed





**Todos**

* Move Monstera to a bigger, more stable pot (probably the old one from the Pachira) and move it to its new place
* Buy or build something for CDs
* Buy a clothes closet
* Build something for old clothes/clothes
* Buy or build a sideboard for in front of the windows
* Buy or build a couch table
* Buy a chair and stool
* Upgrade: find some new cool ideas for more plants, buy some more plants; care for Efeutute and Monstera
* Get rid of keyboard
* Get rid of old standing lamp
* Cabling
* Move pictures near window somewhere else (maybe next to the picture of dad)
* Make the drawer underneath the bed more clean