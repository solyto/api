Solyto can replace

* Notion
* Obsidian
* Evernote
* Goodreads
* Discogs
* Nextcloud
* Calendars
* Contacts
* Finance Trackers
* News Readers
* Todoist
* OneNote
* Any.do