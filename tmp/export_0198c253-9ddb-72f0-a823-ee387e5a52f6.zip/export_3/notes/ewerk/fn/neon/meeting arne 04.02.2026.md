Cidaas-Synchronisierung Test-System
Generell Dev-System Login visuell
"Sie sind schon eingeloggt"
-> "Ich übernehme die Session"-Button
Session beenden bei Cidaas
Altes Login / neues Login