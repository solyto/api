**Übersicht**

* Import
* Eigener Bereich in der Turniersuche
* Veränderte Detail-Anzeige
* Eigener Nennprozess
* Meine Nennungen
* Export
* TORIS-Export
* MessageQueue





**Allgemeines (6h)**

* Abzeichen-Tabelle in Datenbank erstellen (2h)
* Neue Abzeichen-Turnier-Tabelle (2h)
* Neue Abzeichen-Nennung-Tabelle (2h)





**Import (6-8h)**

* XML-Import über PHP-Job (6h)
* Turnier-Metadaten einlesen
* Richter einlesen
* Abzeichen einlesen
* Neue Cronjobs eintragen





**Turniersuche (28h)**

* siehe NEON-2808





**Turnier-Detailanzeige (23h)**

* Detailseite für Abzeichen-Prüfungen (8h)
* Neue Route + SecurityPlugin
* Veränderte Anzeige für Administrator\*innen

  * Detail-Anzeige (2h)
  * Einige Navigations-Punkte fliegen für Abzeichen-Prüfungen raus (1h)
  * Restliche Navigations-Punkte bekommen einen If-Else-Switch und ziehen sich die Daten aus der Abzeichen-Prüfungen-Tabelle (12h)
* Frage: Gibt es Ergebnisse auf Erfolgsdaten?
* Frage: nennen wir "Turniere" in "Veranstaltungen" um?





**Nennprozess (28h)**

* Neue Header-Grafik (keine Pferde, Leistungen) (1h)
* Nennprozess duplizieren & anpassen (24h)

  * u.a. Pferde raus, Voltigier-Logik raus, Luxemburg-Logik raus, etc.
* Neue Routen + SecurityPlugin (3h)
* Geänderte Anzeige der Prüfungen
* Eigenen Backend-Prozess fürs Nennen von Abzeichen-Prüfungen
* Frage: Nennen für Andere berücksichtigen?





**Export (16h)**

* TORIS (10h)

  * Anpassungen MessageQueue (neuer Typ) (4h)
  * Ansteuerung neue Portrix-API / Anpassungen bestehender APIs (4h)
  * Anpassungen TORIS-Anzeige (2h)
* Lastschriften (6h)









**Gesamtschätzung Stand jetzt: 6 + 8 + 28 + 23 + 28 + 16 = 109h (2.7 Wochen)**