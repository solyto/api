# Abschätzung PA -> Pferdesport





1. 301-Weiterleitung: Umleitungen in Nginx einrichten (1h)
2. Google Search Console: wer hat Zugriff und muss das machen?
3. Sitemaps: haben wir Sitemap für Evopage? 





**Extra-Fragen**

FN-Proxy checken: muss hier was umgestellt werden?