



```MySQL
SELECT
    c.entity_id AS user_id,
    c.email,
    c.password_hash AS password,
    v.value AS fnNumber
FROM customer_entity c
INNER JOIN customer_entity_varchar v
    ON v.entity_id = c.entity_id
   AND v.attribute_id = 149
   AND v.value IS NOT NULL
LEFT JOIN cidaas_migration m
    ON c.entity_id = m.magento_user_id
WHERE
    m.migrated_at < '2026-01-01 00:00:00'
    AND (m.incompatible_password != 1 OR m.incompatible_password IS NULL)
    AND m.misc_error IS NULL
    AND c.email NOT IN (
        'muskalla@ewerk.de',
        'ahrens@ewerk.de',
        'kobs@ewerk.de'
    )
LIMIT $limit;

```