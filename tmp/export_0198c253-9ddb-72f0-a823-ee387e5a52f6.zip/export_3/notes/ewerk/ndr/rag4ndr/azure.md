Entra-Anbindung

client secret:   E-t8Q\~X49YicMln.jBk-QDMDOtWHzWufztNeCbCj

 Client ID:   36c0da25-2819-4525-944f-edd9a21b2cf3

 

Tennant ID:  14231bc8-8718-48a7-88e2-0ac25c6234b4

 

 

Object ID:7d09ae8c-8ede-4afe-a1db-5fe2f5453fa4









# Cosmos DB





url: [https://ai4ndr-rag.documents.azure.com:443/](https://ai4ndr-rag.documents.azure.com:443/ "https://ai4ndr-rag.documents.azure.com/")

 

primary key : s95OW2P1ngfA15A2d5dHcknNoldzgcF9nt1vv08Z04opcxR0EztAx3YXce6IlujgkCVbNjKTCBq5ACDbYqWaWA==

 

Primary Connection string:  AccountEndpoint=[https://ai4ndr-rag.documents.azure.com:443/;AccountKey=s95OW2P1ngfA15A2d5dHcknNoldzgcF9nt1vv08Z04op…](https://ai4ndr-rag.documents.azure.com:443/;AccountKey=s95OW2P1ngfA15A2d5dHcknNoldzgcF9nt1vv08Z04opcxR0EztAx3YXce6IlujgkCVbNjKTCBq5ACDbYqWaWA==; "https://ai4ndr-rag.documents.azure.com/;accountkey=s95ow2p1ngfa15a2d5dhcknnoldzgcf9nt1vv08z04opcxr0eztax3yxce6ilujgkcvbnjktcbq5acdbyqwawa==;")