* Content (DONE)

* Blog (DONE)

* Info

* FAQ ([https://ndr.coyocloud.com/pages/d-ein-sap/apps/wiki/faq/list/view/b763e522-ec94-46fd-a28b-c32f1baaabcb)](https://ndr.coyocloud.com/pages/d-ein-sap/apps/wiki/faq/list/view/b763e522-ec94-46fd-a28b-c32f1baaabcb)

* Wiki DONE (<https://ndr.coyocloud.com/pages/geschaeftsleitung-neues/apps/wiki/sitzungsprotokolle/list/view/8680f463-b08c-4397-99dd-e110396029d4>[)](https://ndr.coyocloud.com/pages/d-ein-sap/apps/wiki/faq/list/view/b763e522-ec94-46fd-a28b-c32f1baaabcb)

* Kolleg\*innen-Profile ([https://ndr.coyocloud.com/colleagues) -> https://ndr.coyocloud.com/web/users?term=\&filters=\&searchFields=displayName,properties.jobTitle,properties.department,email,properties.phone,properties.haiilo\_pronouns,properties.bereich1,properties.bereich2,properties.bereich3\&aggregations=subscribedTo=1\&subscribedBy=1\&subscribedNot=1\&availability=1\&haiilo\_pronouns=100\&department=100\&location=100&\_orderBy=lastname.sortV2,firstname.sortV2&\_page=0&\_pageSize=24](https://ndr.coyocloud.com/colleagues)

* Dokumenten-Apps

* Dateiablagen DONE ([https://ndr.coyocloud.com/pages/betriebssport/apps/file-library/versicherungsschutz)](https://ndr.coyocloud.com/pages/betriebssport/apps/file-library/versicherungsschutz)

* ggf. Veranstaltungen ([https://ndr.coyocloud.com/events)](https://ndr.coyocloud.com/events)

* ggf. Timeline ([https://ndr.coyocloud.com/pages/fort-und-weiterbildung/apps/timeline/board)](https://ndr.coyocloud.com/pages/fort-und-weiterbildung/apps/timeline/board)

* ggf. Forum





Kolleg\*innen-Daten mit rein -> eigene Collection

alte Dateien erst mal nicht annehmen

JSON statt XML





aad\_leanderm\@ndr.de NordDeutschAzure88!