**Container**

* PHP-FPM

* Nginx

* Redis

* Python





**Datenbanken**

* Qdrant (SaaS)

* MySQL





**Offene Fragen**

* Gitlab Secrets
* Gitlab Repo Chatbot
* Gitlab Repos Zugang
* Gitlab Variables & Secrets
* Azure Zugang Ressourcen
* Domains