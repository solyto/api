# Bots

**HausenBob**
reminds Hausen about events in the shared calendar

**Notionfy**
sets up a connection to Notion databases and can send reminders, e.g. for reminding about tasks

**KI für Bunt**
lets you post hateful comments and automatically generate useful responses

**Müll Helfer Bremen**
lets you input your address and get notifications about upcoming garbage retrieval dates and types

**"Big News" Morgans**
scans tcbscans.me to grab all or the newest chapter of One Piece

**Fomo Bremen**
scans fomobremen to get daily or all events upcoming in Bremen