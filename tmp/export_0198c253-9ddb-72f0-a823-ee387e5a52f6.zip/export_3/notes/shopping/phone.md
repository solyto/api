Gute Marken:

* Realme (z.B. 14 Pro+)
* OnePlus (z.B. 13R, aber teuer)
* A56 Kameras schlecht
* Nothing Phone 3a statt 3a Pro