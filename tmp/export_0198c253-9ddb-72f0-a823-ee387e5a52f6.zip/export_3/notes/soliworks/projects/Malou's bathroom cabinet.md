**Requirements**

* Mirror
* Light
* Aethetic





**Dimensions**

* 500-600 x 500-600 x 150 (HxBxT)





**Materials**

* Mirror: custom fabrication or small 5x5 tiles





**Ideas**

* Wooden frame
* Open shelfs
* One door