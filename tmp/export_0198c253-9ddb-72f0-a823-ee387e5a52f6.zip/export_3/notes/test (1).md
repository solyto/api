<h1>Backup Server — How To Add a Client</h1><p>The backup server runs an SFTP server (<code>atmoz/sftp</code>) on port 2222. Clients use restic to back up their data to it. Authentication is via SSH key. Encryption is handled entirely by restic on the client side — the server only stores encrypted blobs and never sees plaintext data.</p><hr><h2>Step 1 — Generate a dedicated SSH key on the client</h2><p>On the client machine, generate a key pair used exclusively for backups:</p><pre><code class="language-bash">ssh-keygen -t ed25519 -f ~/.ssh/backup_haupi -C "clientname@backup"
</code></pre><p>This creates:</p><ul><li><p><code>~/.ssh/backup_haupi</code> — private key, stays on the client, never shared</p></li><li><p><code>~/.ssh/backup_haupi.pub</code> — public key, hand this to the server admin</p></li></ul><hr><h2>Step 2 — Add the client to the backup server</h2><p>On the <strong>haupi repo</strong> (<code>backup/</code>):</p><ol><li><p>Copy the client's public key to:</p><pre><code>deployment/docker/keys/{username}.pub
</code></pre></li><li><p>Create the user's data directory on the server (requires root):</p><pre><code class="language-bash">ssh root@haupi mkdir -p /mnt/hdd3/{username}
</code></pre></li><li><p>Deploy:</p><pre><code>make deploy
</code></pre></li></ol><p>The playbook syncs the key and restarts the SFTP container, which creates the SFTP user and <code>data/</code> subdirectory on startup.</p><hr><h2>Step 3 — Install restic on the client</h2><pre><code class="language-bash">apt-get install -y restic
</code></pre><hr><h2>Step 4 — Set up encryption and backups on the client</h2><h3>Add the server to SSH config</h3><p>Add to <code>~/.ssh/config</code>:</p><pre><code>Host backup.sozialit.de
    User username
    Port 2222
    IdentityFile ~/.ssh/backup_haupi
</code></pre><p>Test the connection:</p><pre><code class="language-bash">sftp -P 2222 username@backup.sozialit.de
# should connect and show an empty /data directory
</code></pre><h3>Generate an encryption key file</h3><pre><code class="language-bash">mkdir -p /etc/restic
dd if=/dev/urandom bs=1024 count=4 | base64 &gt; /etc/restic/repo.key
chmod 400 /etc/restic/repo.key
</code></pre><p>Copy the contents (<code>cat /etc/restic/repo.key</code>) into KeePass or a secrets manager. To restore on a new machine, paste the value back into <code>/etc/restic/repo.key</code>.</p><p><strong>If you lose this key, the backups are unrecoverable.</strong></p><h3>Initialize the restic repository</h3><pre><code class="language-bash">restic -r sftp:username@backup.sozialit.de:data init --password-file /etc/restic/repo.key
</code></pre><h3>Run a backup</h3><pre><code class="language-bash">restic -r sftp:username@backup.sozialit.de:data backup /path/to/data --password-file /etc/restic/repo.key
</code></pre><h3>Apply retention policy (keep last 7 snapshots)</h3><pre><code class="language-bash">restic -r sftp:username@backup.sozialit.de:data forget --keep-last 7 --prune --password-file /etc/restic/repo.key
</code></pre><h3>Crontab example (backup + prune daily at 2am)</h3><pre><code>RESTIC_REPOSITORY=sftp:username@backup.sozialit.de:data
RESTIC_PASSWORD_FILE=/etc/restic/repo.key

0 2 * * * restic backup /path/to/data &amp;&amp; restic forget --keep-last 7 --prune
</code></pre><h3>Verify a backup</h3><pre><code class="language-bash">restic -r sftp:username@backup.sozialit.de:data snapshots --password-file /etc/restic/repo.key
restic -r sftp:username@backup.sozialit.de:data check --password-file /etc/restic/repo.key
</code></pre><h3>Restore a backup</h3><pre><code class="language-bash">restic -r sftp:username@backup.sozialit.de:data restore latest --target /path/to/restore --password-file /etc/restic/repo.key
</code></pre><p></p>