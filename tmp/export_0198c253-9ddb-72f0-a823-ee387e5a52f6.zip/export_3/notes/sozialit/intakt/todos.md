* Check PCs if they are still good enough, otherwise buy new ones
* Switch to Linux
* Use Case: Homework, Office, Internet