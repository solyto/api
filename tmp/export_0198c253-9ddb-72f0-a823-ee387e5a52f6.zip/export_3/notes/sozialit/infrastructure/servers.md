### sose1

* sozialit

* solyto

* soliweb

* solicloud

### sose2

* Sig Beratungscloud

### haupi

* UptimeKuma (Souptime)

* Paperless

* HausenCloud