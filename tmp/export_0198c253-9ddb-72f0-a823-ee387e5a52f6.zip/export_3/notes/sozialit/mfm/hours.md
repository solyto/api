15.09. 4 hours

16.09. 3 hours

18.09. 3 hours

28.09. 2.5 hours

29.09. 5 hours

30.09. 1 hour

03.11. 2 hours

04.11. 0.5 hours

08.11. 1 hours

02.12. 1 hour

17.12. 3 hours

Beginning of January: 2 hours

17.02. 3 hours





**Total: 35 hours**

Paid: 81 hours





Hourly wage: 80 euros