* transparency

* assessment

* web scraping

* nlp

* structured data capture

* evaluate docs and generate questions -> **human feedback loop**

* scores, texts

* email dispatch

* mfa

* notifications -> which channels?

* modularity, logging

* which ai model parameters? which providers and models should be supported?

* which pages should be crawled?

* where should files be stored? how sensitive are they? how is transfer of documents security validated?

* xlsx definitiv möglich

* pre-train model?

* queue?

* auth

* database mvp very small

* hosting -> EU?

* token budget

* user documentation?





Hallo Niclas, hallo Eric & Simone,

nachdem ich die letzte Woche flach lag, bin ich jetzt endlich dazu gekommen, mir eure Spezifikation anzuschauen.

Ich hatte etwas Schwierigkeiten, den genauen Einsatzzweck der Software zu ergreifen. Der grundsätzliche Rahmen ist mir klar, jedoch hat sich für mich kein klarer Zusammenhang zwischen den User Journeys ergeben. Ich sehe viele einzelne Module/Aspekte, aber noch nicht das große Ganze - das mag aber nicht unwahrscheinlich an meinem mangelnden Kontext-Wissen liegen.

Dennoch fände ich es praktisch,

1. die verschiedenen Rollen klarer zu definieren (wer sind Clients, wer sind Auditors, etc.)
2. den Zusammenhang zwischen den Akteuren und den ihnen zur Verfügung stehenden Utilities genauer zu beschreiben - was haben Clients und Auditors miteinander zu tun? Was genau bezwecken die Surveys? Wofür werden Angebote und Rechnungen geschrieben? Ggf. wäre hier eine kleine Skizze/Grafik hilfreich, die den User Flow mit den verschiedenen Rollen beschreibt.

Aber nun zum Technischen. Für mich liest sich das Dokument etwas sehr nach Schlagwort-Party, ohne an vielen Stellen tatsächlich konkret zu werden. Zusätzlich ist mir, auch bedingt durch mein oben erwähntes mangelndes Verständnis für das große Ganze, nicht ganz klar, wie das Zusammenspiel der technischen Komponenten aussehen soll. Soweit aber nicht tragisch, dafür gibt es ja dann den Workshop und Klärungsphasen. Nachfolgend findet ihr einige unsortierte Anmerkungen und Anmerkungen, die bei mir aufgekommen sind.

**CRM-System**

Der Punkt ist sehr wage. Gibt es ein bestehendes CRM-System, soll ein CRM als Service zusätzlich aufgesetzt werden, soll die neue Software CRM-Funktionalitäten haben? Das könnte ein riesig großer Punkt werden, insbesondere im Hinblick auf Datensicherheit und Robustheit, insofern fände ich es wichtig hier genauer zu spezifieren welche Funktionen und/oder Anbindungen gewünscht sind.

**Authentifizierung**

Wie genau soll die Authentifizierung aussehen? Soll das System eine eigene User\*innen-Datenbank beinhalten oder soll die Anmeldung über bestehende Authentifizierungssystem laufen (OAuth à la Microsoft, Cidaas, etc.)? Gibt es für MFA Anforderungen, welche MFA-Mechanismen unterstützt werden müssen (E-Mail, SMS, Apps, etc.)?

**Benachrichtigungen & E-Mails**

Soll es weitere Benachrichtigungs-Channel als E-Mails geben (z.B. Slack, Teams, etc.)? Über welchen Dienst sollen E-Mails verschickt werden? Gibt es dafür bereits eine bestehende Infrastruktur? Bei E-Mails ist natürlich vor allem wichtig, dass man selten bis nie im Spam-Ordner landet - das könnten bestimmte Dienste wie Postmark ziemlich gut, eigene SMTP-/Mail-Server würde ich hier meiden wollen. Je nach Entscheidung kostet das aber natürlich monatlich und es ist auch die Frage, wer das managed.

**Handbuch**

Wie groß soll das Handbuch, das zur Bewertung durch KI dient, sein? Geht es hier um Text-Bausteine, die die Regeln beschreiben? Und gibt es das Handbuch bereits? Grundsätzlich halte ich den Ansatz für richtig, möglichst viel deterministisch durch selbst-programmierte Algorithmen zu lösen und KI nur dort einzusetzen, wo das Verstehen/Generieren von Text nötig ist. Ein Handbuch, was Regeln nur beschreibt, könnte - je nach Umfang - einerseits den Kontext-Rahmen von Modellen sprengen, andererseits nicht spezifisch genug sein. Hier solltet ihr unbedingt vermeiden, dass ihr für zu viele Dinge KI benutzt - das macht den ganzen Prozess instabil und wenig nachvollziehbar. Wo es geht sollten feste, deterministische Bausteine verwendet werden.

**KI**

Ich fände es wichtig, dass ihr für die Spezifikation ergänzt, welche Art von Modellen verwendet werden sollen. Wollt ihr eine API einer der großen Anbieter verwenden, ein OpenAI Model in Microsoft Azure hosten (DSGVO-konform), ein eigenes Model auf Basis frei verfügbarer Modelle trainieren und selbst laufen lassen oder oder. Auf Basis eures Entschluses verändert sich die technische Umsetzung des Ganzen sehr stark. Für eine API-basierte Software kommen mitunter ganz andere Entwickler\*innen in Frage als für eine Software, die Algorithmen und Pre-Training vereinen muss. Ebenso wichtig fände ich eine Richtlinie, was euer perspektivisches monatliches Budget für KI-Kosten sind?

Wollt ihr die verschiedenen Inhalte nur abspeichern und dann auswerten? Oder sollen die Dateien auch durchsucht werden können? Das ginge dann in Richtung RAG wie wir es beim Myfairmoney Chatbot haben.

**Infrastruktur**

Wo soll das Ganze laufen? Ihr sprecht von Cloud-native, d.h. ihr wollt das Ganze in der Cloud haben? Habt ihr dafür bereits Infrastruktur oder ist das Teil des Auftrags?

Generell: aus welchem Grund wollt ihr in die Cloud? Das ist zwar hipp und in vielerlei Hinsicht sehr praktisch, endet aber oft in einer fiesen Kostenfalle. Auf den ersten Blick sind Cloud-Infrastrukturen wie Azure und AWS unfassbar modular, dynamisch und die Einzelpreise günstig, in der Summe zahlt man aber häufig bedeutend mehr als für Dedicated Server. Das liegt daran, dass man für jede Ressource bezahlt - Network Traffic, Load Balancer Rules, Firewall, Network Storage, Datenbank I/O, etc.

So oder so müsste ja jemand die Wartung der Infrastruktur langfristig handhaben. Wenn ihr also so oder so jemanden an der Hand habt würde ich noch mal überdenken, welche Vorteile euch eine Cloud-Infrastruktur konkret bringt. Auch bzgl. Wartung ist das meistens deutlich mehr Aufwand aufgrund verschiedenster Fallstricke. Falls ihr auf Cloud festgelegt seid, würde ich ein Kubernetes-Cluster empfehlen - damit hat man viele der Cloud-Vorteile, kann aber trotzdem weiter alles selbst konfigurieren und sich einige Cloud-Ressourcen (z.B. Contrainer Orchestrator) sparen, die Geld kosten. Generell würde ich in die Spezifikation auf jeden Fall reinschreiben, dass das Ganze zwecks Datenschutz in der EU gehosted werden sollte.

Bzgl. der einzelnen Infrastruktur-Module fände ich es noch interessant zu wissen, ob ihr euch schon konkret Gedanken gemacht habt? Also welche Art von Datenbank, welche Programmiersprache? Welche Art von Interface wollt ihr haben?

Generell wurde mir nicht 100% klar, ob es sich um eine Software für Desktops handelt, die über APIs kommuniziert, oder über ein Web-Tool?

Wollt ihr von Anbieter\*innen (z.B. bzgl. DSGVO, Barrierefreiheit, etc.) Zertifikate haben? Wollt ihr eine garantierte Uptime des Tools? Wird es einen Wartungsvertrag geben?

**Dateien**

Habt ihr eine Liste von Quellen, von denen Dateien und Inhalte automatisch gecrawled werden sollen? Sind diese frei-zugänglich oder werden sie über APIs mit Authentifizierung abgerufen?

**Dokumentation**

Ich würde neben der Developer Documentation auch noch eine User-Dokumentation für euch und Anwender\*innen fordern.

**Nachvollziehbarkeit / Logging**

Ihr habt, für mein Empfinden, relativ wenig Anteile drin, die sich auf die Nachvollziehbarkeit der automatisierten Prozesse beziehen. Wie wird für euch ersichtlich, was im System passiert, damit das am Ende keine unbedienbare Black Box wird. Welche Indikatoren können euch zur Verfügung gestellt werden, welche Protokoll-Dateien. Welche Metriken soll es geben, um die Qualität der KI-Arbeit zu bewerten?

Am spannendsten neben den eigentlichen Algorithmen ist sicherlich das Ping-Pong zwischen KI und Menschen (Human Feedback Loop). Dazu würde ich einen sehr konkreten Entwurf fordern, wie eine potenzielle Firma das umsetzen würde. Welche Art von Feedback können User\*innen geben und auf welche Art wird diese angewendet? Die Frage bezieht sich natürlich auch stark auf die Themen unter "KI" - das sähe natürlich ganz anders aus beim Trainieren von Modellen im Vergleich zu rein Prompt-basierten Funktionen.

**Tests**

Ihr erwähnt Tests, habt ihr konkrete Erwartungen dazu? Also z.B. bestimmte Test Coverage-Werte? Für welche Aspekte wollt ihr Tests haben?

**Machbarkeit**

Das Projekt wirkt auf jeden Fall sehr ambitioniert. Aber es ist gut in Module aufgeteilt, dadurch lässt sich das leichter bewerten. Viele einzelne Aspekte scheinen mir gut umsetzbar (Web Crawling, Export in Dateiformate, etc.). Der Knackpunkt liegt in meiner Sicht daran, was das Scoring genau können soll und welche Anteile daran die KI übernehmen soll. Wie oben bereits erwähnt bin ich nicht überzeugt davon, dass man komplexe Prozesse durch KI gut lösen kann. Als "Übersetzer" von strukturierten Daten zu Sprache und zurück dagegen schon. Könnt ihr die erwarteten Ergebnisse der Algorithmen genauer erläutern?





So, da erst mal als großer Block Anmerkungen. Vielleicht besprechen wir das in Person genauer?





Viele Grüße

Leo