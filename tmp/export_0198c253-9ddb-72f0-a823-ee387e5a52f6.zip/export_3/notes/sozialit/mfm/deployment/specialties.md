livewire.js must be copied to public/vendor/livewire/livewire.js

config/services.php -> api url must be adjusted

.env files cannot be overwritte